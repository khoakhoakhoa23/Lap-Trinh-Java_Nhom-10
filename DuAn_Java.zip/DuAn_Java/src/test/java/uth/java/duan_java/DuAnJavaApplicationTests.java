package uth.java.duan_java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DuAnJavaApplicationTests {

    @Test
    void contextLoads() {
    }

}
